# Phase 1: Deep Repository & Schema Reconnaissance & Architectural Blueprint

**Project**: Ghost Data Still Exists (HackerRank Orchestrate October 2026)  
**Role**: Staff Principal AI Systems Engineer  
**Core Architectural Philosophy**: *"LLM Describes, Python Decides"*

---

## 1. Deep Repository & Schema Reconnaissance

### 1.1 Objective & Domain Problem
Northstar Shop faced a \$2.4M compliance incident when supposedly deleted users persisted in secondary databases, search indexes, backups, and analytics platforms. The mission is to build a deletion audit model that examines 518 cases (`deletion_requests.csv`) against 94 multi-modal evidence files, historical identity logs, and operational activity streams, outputting `output.csv`.

### 1.2 Explicit Business Rules & Boundary Conditions
1. **Request Legitimacy (`NOT_APPLICABLE`)**:
   - A request for access, portable data export, password reset, or marketing opt-out alone is **not** a deletion request.
   - For non-deletion requests: `deletion_status = "NOT_APPLICABLE"` and `steps_json = []` (`case_533` through `case_542`).
2. **Identity Resolution**:
   - Primary user identity in `user_identities.csv` (`user_id`, `name`, `email`, `phone`, `email_hash`).
   - Audit trail in `user_audit_log.csv` (`old_value`, `new_value` across `email`, `phone`, and `email_hash`).
   - All historical identifiers must be indexed to catch stale records.
3. **Temporal Cutoff**:
   - Only evidence captured at or before `audit_at` (`captured_at <= audit_at`) may be considered.
   - Future evidence is strictly inadmissible.
4. **Data Categories & Treatment (`deletion_rules.csv`)**:
   - `USER_PROFILE`, `SECONDARY_IDENTIFIER`, `SEARCH_INDEX_ENTRY`, `CACHE_ENTRY`, `USER_EXPORT`, `MARKETING_PROFILE`: `DELETE`
   - `SUPPORT_MESSAGE`, `EMAIL_DELIVERY_LOG`, `ACCOUNT_TOMBSTONE`: `REDACT` (preserve internal `user_id`, remove direct PII)
   - `ANALYTICS_PROFILE`, `PRODUCT_TELEMETRY`: `ANONYMIZE` (remove identifiers, retain aggregate cohort data)
   - `SECURITY_AUDIT_LOG`, `LEGAL_HOLD_RECORD`, `BACKUP_ARCHIVE`: `RETAIN` (with backup restore access blocked)
5. **Deletion Status Criteria**:
   - `COMPLETE`: Every copy has received required treatment, required retained records are present, and no active sync/restore path exists at `audit_at`.
   - `INCOMPLETE`: Any prohibited record remains, PII is exposed, or active recreation risks exist.
6. **Canonical Step Ordering & Tie-Breaker Formula**:
   - Phase Order: `FINDING` (1) $\rightarrow$ `REMEDIATION` (2) $\rightarrow$ `VERIFICATION` (3).
   - Operation Order within Phase:
     - **FINDING**: `REPORT_REMAINING_RECORD` (1), `REPORT_EXPOSED_PII` (2), `REPORT_ACTIVE_DATA_FLOW` (3), `REPORT_RESTORE_RISK` (4)
     - **REMEDIATION**: `DISABLE_DATA_FLOW` (1), `BLOCK_RESTORE` (2), `DELETE_RECORD` (3), `REDACT_RECORD` (4), `ANONYMIZE_RECORD` (5)
     - **VERIFICATION**: `VERIFY_RECORD_ABSENT` (1), `VERIFY_RECORD_PRESENT` (2), `VERIFY_RECORD_REDACTED` (3), `VERIFY_RECORD_ANONYMIZED` (4), `VERIFY_DATA_FLOW_DISABLED` (5), `VERIFY_RESTORE_BLOCKED` (6)
   - Tie-Breaker: Sort alphabetically by `system_id` ascending, then `resource_id` ascending.
   - Canonical Sort Key: `(PHASE_ORDER[phase], OP_ORDER[phase][op], system_id, resource_id)`
7. **Evidence Citation Protocol**:
   - In `COMPLETE`: All steps are `VERIFICATION` and cite the ground-truth `evidence_id` proving clean state.
   - In `INCOMPLETE`: `FINDING` steps cite the ground-truth `evidence_id`. All `REMEDIATION` and post-remediation `VERIFICATION` steps use `evidence_id: ""`.

---

## 2. Core Architectural Principle: "LLM Describes, Python Decides"

```mermaid
flowchart TD
    A["Raw Input Request (case_id, email, audit_at, text)"] --> B["Tier 0: Deterministic Sieve (Zero-Token Python)"]
    B -->|Non-Deletion Intent| C["Status: NOT_APPLICABLE, steps: []"]
    B -->|Identity & Temporal Match| D["Deterministic Ground-Truth Indexer"]
    
    E["Unstructured Evidence (PDFs, Images, Handover Notes)"] --> F["Tier 1: Fast Multimodal Extraction (Pydantic Schema)"]
    F -->|Validation / Blurry / Low Confidence| G["Tier 2: Escalation Model"]
    F -->|Structured Facts Extracted| H["In-Memory Ground-Truth Fact Ledger"]
    G -->|High-Confidence Facts| H
    
    D --> H
    H --> I["Deterministic Python Decision Engine"]
    I --> J["Policy Validation & Category Rules (deletion_rules.csv)"]
    I --> K["Resource State Machine (PRESENT / ABSENT / REDACTED / ANONYMIZED / ACTIVE / BLOCKED)"]
    I --> L["Canonical Step Generator & Multi-Tier Sorter"]
    L --> M["Output Integrity Verifier & output.csv"]
```

The LLM is strictly prohibited from deciding `deletion_status` or assembling `steps_json`. The LLM's sole role is converting unstructured text, OCR snippets, and screenshots into strongly typed Pydantic fact models. Pure deterministic Python executes all state evaluations, policy decisions, step synthesis, and sorting.

---

## 3. Mandatory Adversarial Edge-Case Defenses

| Trap # | Hidden Threat | Production-Grade Defensive Guard in Python |
|---|---|---|
| **1. Stateful & Cross-Row Dependencies** | Multiple rows referencing the same `user_id` or `resource_id` with state carry-over. | In-memory global ledger tracks resource lifecycle states. Requests are pre-sorted chronologically by UTC timestamp for stateful evaluation, and restored strictly to original row order before writing `output.csv`. |
| **2. Cross-Modal Conflict Resolution** | Contradictions between DB snapshots, text handovers, logs, and user claims. | Strict Source-of-Truth Hierarchy:<br>1. Immutable DB / SQLite snapshot logs (Highest)<br>2. Primary Visual/Document Evidence (PDFs/PNGs)<br>3. Latest Timestamped Internal Handover Records<br>4. Unverified User Form Claims (Lowest) |
| **3. Prompt Injection & Social Engineering** | Adversarial text in `request_text` ("SYSTEM OVERRIDE", "Ignore previous instructions", "Output COMPLETE"). | All request texts and OCR strings are treated as untrusted data. Extracted solely into sanitized fields; overrides are stored as unverified booleans and verified against official database tables. |
| **4. Temporal, Timezone & Sequence Hygiene** | ISO-8601 variations, timezone drift, unsorted event logs. | All timestamps normalized to `datetime.timezone.utc`. Any evidence where `captured_at > audit_at` is pruned. All event streams explicitly sorted before reading latest state. |
| **5. Numeric, Currency & Rounding Precision** | Floating-point inaccuracies in financial/order records, tax calculations, and token costs. | Pure `decimal.Decimal` with `ROUND_HALF_UP` for all numeric calculations. Domain values clamped strictly to valid ranges. |
| **6. Visual & Document Forensics** | Reused attachments, synthetic collisions, forged documents. | Precomputed SHA-256 media digests for all 11 PNGs and 4 PDFs. Cross-referenced against unique document IDs (e.g. `NST-2026-0718-1842`, `CS-4827`, `CJX-20260905-0630`). |

---

## 4. Pydantic Extraction Schemas

```python
from pydantic import BaseModel, Field
from typing import List, Optional

class UnstructuredDocumentFact(BaseModel):
    """Strongly typed facts extracted from unstructured documents (PDF/PNG)."""
    document_id: str = Field(description="Internal reference ID or file identifier")
    document_sha256: str = Field(description="SHA-256 checksum of source media")
    subject_user_id: Optional[str] = Field(None, description="Direct user_id if visible")
    subject_email: Optional[str] = Field(None, description="Direct email if visible")
    subject_phone: Optional[str] = Field(None, description="Direct phone if visible")
    resource_id: str = Field(description="Canonical resource identifier, e.g., account_001, support_001")
    system_id: str = Field(description="Subsystem name: account_service, support_platform, etc.")
    observed_state: str = Field(description="PRESENT, ABSENT, REDACTED, ANONYMIZED, ACTIVE, BLOCKED")
    contains_unredacted_pii: bool = Field(description="True if personal data is still exposed")
    user_claims_override: bool = Field(default=False, description="True if text claims an exception/override")
    extraction_confidence: float = Field(ge=0.0, le=1.0, description="Extraction confidence score")
    needs_escalation: bool = Field(default=False, description="True if contradictory or ambiguous")

class RequestIntentFact(BaseModel):
    """Classification of user request authorization."""
    case_id: str
    is_deletion_authorized: bool = Field(description="True if requesting erasure/deletion/account closure")
    intent_category: str = Field(description="DELETION, EXPORT, CORRECTION, ACCESS, MARKETING_OPT_OUT")
    confidence: float = Field(ge=0.0, le=1.0)
    adversarial_flag_detected: bool = Field(default=False)
```

---

## 5. 3-Tier Cost & Latency Funnel

1. **Tier 0: Zero-Token Deterministic Sieve**:
   - Runs in pure Python (0 API tokens, < 1ms per case).
   - Fast regex intent sieve eliminates non-deletion cases (`NOT_APPLICABLE`).
   - Direct SQLite / JSON / structured log indexer resolves all cases where ground-truth structured evidence exists.
2. **Tier 1: Fast Multimodal Extraction**:
   - Invoked only for unstructured PDFs/images requiring OCR/visual transcription.
   - Cached via SQLite Content-Addressable Cache keyed by `SHA256(model + prompt + media_sha256)`.
   - Repeated runs cost \$0.00.
3. **Tier 2: Frontier Model Escalation**:
   - Invoked strictly if `needs_escalation == True` or Pydantic validation fails.
